namespace TP2_Structures
{
    partial class frmAccueil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnFactoriel = new System.Windows.Forms.Button();
            this.BtnTab = new System.Windows.Forms.Button();
            this.BtnJouer = new System.Windows.Forms.Button();
            this.BtnQuitter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnFactoriel
            // 
            this.BtnFactoriel.Location = new System.Drawing.Point(100, 30);
            this.BtnFactoriel.Name = "BtnFactoriel";
            this.BtnFactoriel.Size = new System.Drawing.Size(150, 40);
            this.BtnFactoriel.TabIndex = 0;
            this.BtnFactoriel.Text = "Calcul Factoriel";
            this.BtnFactoriel.UseVisualStyleBackColor = true;
            this.BtnFactoriel.Click += new System.EventHandler(this.BtnFactoriel_Click);
            // 
            // BtnTab
            // 
            this.BtnTab.Location = new System.Drawing.Point(100, 90);
            this.BtnTab.Name = "BtnTab";
            this.BtnTab.Size = new System.Drawing.Size(150, 40);
            this.BtnTab.TabIndex = 1;
            this.BtnTab.Text = "Les tableaux";
            this.BtnTab.UseVisualStyleBackColor = true;
            this.BtnTab.Click += new System.EventHandler(this.BtnTab_Click);
            // 
            // BtnJouer
            // 
            this.BtnJouer.Location = new System.Drawing.Point(100, 150);
            this.BtnJouer.Name = "BtnJouer";
            this.BtnJouer.Size = new System.Drawing.Size(150, 40);
            this.BtnJouer.TabIndex = 2;
            this.BtnJouer.Text = "Jouer";
            this.BtnJouer.UseVisualStyleBackColor = true;
            this.BtnJouer.Click += new System.EventHandler(this.BtnJouer_Click);
            // 
            // BtnQuitter
            // 
            this.BtnQuitter.Location = new System.Drawing.Point(100, 210);
            this.BtnQuitter.Name = "BtnQuitter";
            this.BtnQuitter.Size = new System.Drawing.Size(150, 40);
            this.BtnQuitter.TabIndex = 3;
            this.BtnQuitter.Text = "Quitter";
            this.BtnQuitter.UseVisualStyleBackColor = true;
            this.BtnQuitter.Click += new System.EventHandler(this.BtnQuitter_Click);
            // 
            // frmAccueil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 280);
            this.Controls.Add(this.BtnQuitter);
            this.Controls.Add(this.BtnJouer);
            this.Controls.Add(this.BtnTab);
            this.Controls.Add(this.BtnFactoriel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmAccueil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TP 2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnFactoriel;
        private System.Windows.Forms.Button BtnTab;
        private System.Windows.Forms.Button BtnJouer;
        private System.Windows.Forms.Button BtnQuitter;
    }
}
